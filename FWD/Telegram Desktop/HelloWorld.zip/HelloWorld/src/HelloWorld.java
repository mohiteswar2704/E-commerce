


class Human{
	int age = 20;
	void sleep(int a){ //Method Signature
		System.out.println("Human exists on earth.");
	}
	
}
public class HelloWorld {
	int a = 100;
	static int aa = 90;
	public static void main(String[] s) {
		Human h = new Human();
		int value = 10;
		System.out.println("Hello World");
		System.out.println(h.age);
		h.sleep(value);;
	}
}

//local variables
//instance variables
//static variables