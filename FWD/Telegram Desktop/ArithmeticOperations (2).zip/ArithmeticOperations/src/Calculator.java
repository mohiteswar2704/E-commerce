class CalculatorOperation {

	public CalculatorOperation() {
		//this();
		this(true,"Happy",45.0f,45.9);
	}
	//Zero parameterized constructor
	CalculatorOperation(boolean b, String s,float f,int d){
		
		this();
	}
	
	
	//parameterized constructor
	CalculatorOperation(boolean b, String s,float f,double d){
		this.welcomeMessage = b;
		this.welcomeMessage2 = s;
		this.welcomeMessage3 = f;
		this.welcomeMessage4 = d;
	}
	boolean welcomeMessage;
	String welcomeMessage2;
	float welcomeMessage3;
	double welcomeMessage4;
	CalculatorOperation welcomeMessage5;
//	Hello hello;
	byte h1 = 123;
	short h2 = 129;
	int h3 = 1234567;
	long h4 = 14443243243242L;
	
	
	
	  char a = 4567; 
	  int i = 123; 
	  byte b = (byte)i; //Typecasting 
	  long l = i; //Type promotion
	  
	  byte b1 = 10; 
	  long b2 = 10; 
	  short b3 = (short)(b1*b2);
	  
	  long l1 = 123;
	  long result = l1*i;
	  
	  
	 

	void addition(int a, int b) {
		int c = 10;
		System.out.println(c);
		System.out.println("The addition is: " + (a + b));
	}

	void subtraction(int a, int b) {
		System.out.println(a - b);
	}

	void multiplication(int a, int b) {
		System.out.println(a * b);
	}

	void division(int a, int b) {
		if (b != 0)
			System.out.println(a / b);
		else
			System.out.println("Denominator shouldn't be zero");

	}
}

//Driver or Client
public class Calculator {
	public static void main(String[] a) {
		CalculatorOperation co = new CalculatorOperation(true,"Hello",9.0f,10);
		co.addition(3, 4);
		co.subtraction(5, 6);
		co.multiplication(5, 7);
		co.division(25, -5);
		//co.welcomeMessage=1000;
		System.out.println(co.welcomeMessage);
		System.out.println(co.welcomeMessage2);
		System.out.println(co.welcomeMessage3);
		System.out.println(co.welcomeMessage4);
		System.out.println(co.welcomeMessage5);
		
		
	}
}



//byte - 8 bits - 1 byte -128 to 127
//char - 16 bits - 2 bytes
//short - 16 bits - 2 bytes
//int - 32 bits - 4 bytes - -2^32 to 2^32-1
//long - 64 bits - 8 bytes
//float - 32 bits - 4 bytes
//double - 64 bits - 8 bytes
//String - null
//boolean - true/false - false is default value




